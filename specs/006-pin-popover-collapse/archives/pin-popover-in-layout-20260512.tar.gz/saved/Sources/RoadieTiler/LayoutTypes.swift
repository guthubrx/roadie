import CoreGraphics
import RoadieCore

public struct LayoutRequest: Equatable, Sendable {
    public var scope: StageScope
    public var mode: WindowManagementMode
    public var container: CGRect
    public var windowIDs: [WindowID]
    public var currentFrames: [WindowID: CGRect]
    public var priorityWindowIDs: Set<WindowID>
    public var collapsedWindowHeights: [WindowID: CGFloat]
    public var splitPolicy: String
    public var outerGaps: Insets
    public var innerGap: Double

    public init(
        scope: StageScope,
        mode: WindowManagementMode,
        container: CGRect,
        windowIDs: [WindowID],
        currentFrames: [WindowID: CGRect] = [:],
        priorityWindowIDs: Set<WindowID> = [],
        collapsedWindowHeights: [WindowID: CGFloat] = [:],
        splitPolicy: String = "balanced",
        outerGaps: Insets = .zero,
        innerGap: Double = 0
    ) {
        self.scope = scope
        self.mode = mode
        self.container = container
        self.windowIDs = windowIDs
        self.currentFrames = currentFrames
        self.priorityWindowIDs = priorityWindowIDs
        self.collapsedWindowHeights = collapsedWindowHeights
        self.splitPolicy = splitPolicy
        self.outerGaps = outerGaps
        self.innerGap = max(0, innerGap)
    }
}

public struct LayoutPlan: Equatable, Sendable {
    public var placements: [WindowID: CGRect]

    public init(placements: [WindowID: CGRect]) {
        self.placements = placements
    }
}

public struct LayoutCommand: Equatable, Sendable {
    public let windowID: WindowID
    public let frame: CGRect

    public init(windowID: WindowID, frame: CGRect) {
        self.windowID = windowID
        self.frame = frame
    }
}

public enum LayoutPlanner {
    public static func plan(_ request: LayoutRequest) -> LayoutPlan {
        let basePlan = planWithoutCollapsedAdjustments(request)
        guard !request.collapsedWindowHeights.isEmpty else { return basePlan }
        return applyCollapsedInLayoutHeights(basePlan, request: request)
    }

    private static func planWithoutCollapsedAdjustments(_ request: LayoutRequest) -> LayoutPlan {
        var passthrough = request
        passthrough.collapsedWindowHeights = [:]
        switch passthrough.mode {
        case .bsp:
            return BSPLayoutStrategy().plan(passthrough)
        case .mutableBsp:
            return MutableBSPLayoutStrategy().plan(passthrough)
        case .masterStack:
            return MasterStackLayoutStrategy().plan(passthrough)
        case .float:
            return FloatLayoutStrategy().plan(passthrough)
        }
    }

    private static func applyCollapsedInLayoutHeights(_ basePlan: LayoutPlan, request: LayoutRequest) -> LayoutPlan {
        let gap = CGFloat(request.innerGap)
        var placements = basePlan.placements
        let collapsedIDs = request.windowIDs.filter { request.collapsedWindowHeights[$0] != nil }
        guard !collapsedIDs.isEmpty else { return basePlan }

        for id in collapsedIDs {
            guard let original = placements[id] else { continue }
            let requestedHeight = request.collapsedWindowHeights[id] ?? 28
            let collapsedHeight = min(max(18, requestedHeight), max(18, original.height))
            let freedHeight = max(0, original.height - collapsedHeight)
            let collapsedBand = CGRect(
                x: original.minX,
                y: original.minY,
                width: original.width,
                height: collapsedHeight
            ).integral
            placements[id] = collapsedBand
            guard freedHeight > 0 else { continue }
            expandWindowsBelowCollapsed(
                originalFrame: original,
                collapsedBand: collapsedBand,
                freedHeight: freedHeight,
                gap: gap,
                collapsedIDs: Set(collapsedIDs),
                placements: &placements
            )
        }
        return LayoutPlan(placements: placements)
    }

    private static func expandWindowsBelowCollapsed(
        originalFrame: CGRect,
        collapsedBand: CGRect,
        freedHeight: CGFloat,
        gap: CGFloat,
        collapsedIDs: Set<WindowID>,
        placements: inout [WindowID: CGRect]
    ) {
        let candidates = placements
            .filter { id, frame in
                !collapsedIDs.contains(id) &&
                    frame.minY >= originalFrame.maxY - 1 &&
                    horizontalOverlapRatio(frame, originalFrame) >= 0.65
            }
            .sorted { $0.value.minY < $1.value.minY }
        guard let target = candidates.first else { return }
        let current = target.value
        let newY = max(collapsedBand.maxY + gap, current.minY - freedHeight)
        placements[target.key] = CGRect(
            x: current.minX,
            y: newY,
            width: current.width,
            height: max(18, current.maxY - newY)
        ).integral
    }

    private static func horizontalOverlapRatio(_ first: CGRect, _ second: CGRect) -> CGFloat {
        let overlap = max(0, min(first.maxX, second.maxX) - max(first.minX, second.minX))
        let base = max(1, min(first.width, second.width))
        return overlap / base
    }
}

public enum LayoutDiff {
    public static func commands(previous: LayoutPlan?, next: LayoutPlan) -> [LayoutCommand] {
        next.placements.keys.sorted().compactMap { windowID in
            guard let nextFrame = next.placements[windowID] else { return nil }
            if let previousFrame = previous?.placements[windowID],
               previousFrame.isClose(to: nextFrame, positionTolerance: 1, sizeTolerance: 1) {
                return nil
            }
            return LayoutCommand(windowID: windowID, frame: nextFrame)
        }
    }
}

private extension CGRect {
    func isClose(to other: CGRect, positionTolerance: CGFloat = 48, sizeTolerance: CGFloat = 48) -> Bool {
        abs(minX - other.minX) <= positionTolerance
            && abs(minY - other.minY) <= positionTolerance
            && abs(width - other.width) <= sizeTolerance
            && abs(height - other.height) <= sizeTolerance
    }
}
